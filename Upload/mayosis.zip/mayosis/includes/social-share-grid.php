<?php if(function_exists('mayosis_gridsocial')){
   mayosis_gridsocial();
} ?>