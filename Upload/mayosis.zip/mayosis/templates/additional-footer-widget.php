<div class="additional-footer-widget">
    	<?php if ( is_active_sidebar( 'additional-footer-one' ) ) : ?>
					<?php dynamic_sidebar( 'additional-footer-one' ); ?>
				<?php endif; ?>
</div>
<div class="additional-footer-widget">
    	<?php if ( is_active_sidebar( 'additional-footer-two' ) ) : ?>
					<?php dynamic_sidebar( 'additional-footer-two' ); ?>
				<?php endif; ?>
</div>

<div class="additional-footer-widget">
    	<?php if ( is_active_sidebar( 'additional-footer-three' ) ) : ?>
					<?php dynamic_sidebar( 'additional-footer-three' ); ?>
				<?php endif; ?>
</div>