<?php

// Register Taxonomy Artist
function mayosis_artist_taxonomy() {

	$labels = array(
		'name'              => _x( 'Artists', 'taxonomy general name', 'mayosis' ),
		'singular_name'     => _x( 'Artist', 'taxonomy singular name', 'mayosis' ),
		'search_items'      => __( 'Search Artists', 'mayosis' ),
		'all_items'         => __( 'All Artists', 'mayosis' ),
		'parent_item'       => __( 'Parent Artist', 'mayosis' ),
		'parent_item_colon' => __( 'Parent Artist:', 'mayosis' ),
		'edit_item'         => __( 'Edit Artist', 'mayosis' ),
		'update_item'       => __( 'Update Artist', 'mayosis' ),
		'add_new_item'      => __( 'Add New Artist', 'mayosis' ),
		'new_item_name'     => __( 'New Artist Name', 'mayosis' ),
		'menu_name'         => __( 'Artist', 'mayosis' ),
	);
	$args = array(
		'labels' => $labels,
		'description' => __( '', 'mayosis' ),
		'hierarchical' => true,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => true,
		'show_tagcloud' => true,
		'show_in_quick_edit' => true,
		'show_admin_column' => true,
		'show_in_rest' => true,
	);
	register_taxonomy( 'artist', array('download'), $args );

}
add_action( 'init', 'mayosis_artist_taxonomy' );

if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
	'key' => 'group_5eb4d5ad67447',
	'title' => 'Playlist',
	'fields' => array(
		array(
			'key' => 'field_5eb4d5cabe4cc',
			'label' => 'Playlist Repeater',
			'name' => 'playlist_repeater',
			'type' => 'repeater',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'collapsed' => '',
			'min' => 0,
			'max' => 0,
			'layout' => 'table',
			'button_label' => '',
			'sub_fields' => array(
				array(
					'key' => 'field_5eb4d5e5be4cd',
					'label' => 'Song Title',
					'name' => 'song_title',
					'type' => 'text',
					'instructions' => '',
					'required' => 0,
					'conditional_logic' => 0,
					'wrapper' => array(
						'width' => '',
						'class' => '',
						'id' => '',
					),
					'default_value' => '',
					'placeholder' => '',
					'prepend' => '',
					'append' => '',
					'maxlength' => '',
				),
				array(
					'key' => 'field_5eb4d62bbe4cf',
					'label' => 'Song Cover Image',
					'name' => 'song_cover_image',
					'type' => 'image',
					'instructions' => '',
					'required' => 0,
					'conditional_logic' => 0,
					'wrapper' => array(
						'width' => '',
						'class' => '',
						'id' => '',
					),
					'return_format' => 'url',
					'preview_size' => 'medium',
					'library' => 'all',
					'min_width' => '',
					'min_height' => '',
					'min_size' => '',
					'max_width' => '',
					'max_height' => '',
					'max_size' => '',
					'mime_types' => '',
				),
				array(
					'key' => 'field_5eb631f3b514a',
					'label' => 'Songs',
					'name' => 'cover_songs',
					'type' => 'file',
					'instructions' => '',
					'required' => 0,
					'conditional_logic' => 0,
					'wrapper' => array(
						'width' => '',
						'class' => '',
						'id' => '',
					),
					'return_format' => 'array',
					'library' => 'all',
					'min_size' => '',
					'max_size' => '',
					'mime_types' => 'mp3',
				),
			),
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'download',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

endif;


if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
	'key' => 'group_5eaaede67eb31',
	'title' => 'Artist Fields',
	'fields' => array(
		array(
			'key' => 'field_5eaaee0b351dd',
			'label' => 'Artists Biography',
			'name' => 'artists_biography',
			'type' => 'wysiwyg',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'default_value' => '',
			'tabs' => 'all',
			'toolbar' => 'full',
			'media_upload' => 1,
			'delay' => 0,
		),
		array(
			'key' => 'field_5eaaee415a998',
			'label' => 'Artist Image',
			'name' => 'artist_image',
			'type' => 'image',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array(
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'return_format' => 'url',
			'preview_size' => 'medium',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'taxonomy',
				'operator' => '==',
				'value' => 'artist',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

endif;